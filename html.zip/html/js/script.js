// string
// boolean
// number
// undefined
// null
// Object


let area = "Mogappair"
let areaNumber = 12738
let isValid = true
let country
let continent = null

let object = {
  area: "Mogappair",
  areaNumber: 12738,
  isValid: true,
  country,
  continent: null
}

let = ['1', 2, { name: 'name' }]

const a = 1
const b = 6
const c = 3


// console.log(a + b * c / b);
// console.log((a + b * c) / b);


function normalFunction() {
  return (a + b * c) / b
}


const arrowFunction = (valueA, valueB, valueC) => {
  const cat = 3
  return ((valueA + valueB * valueC) / cat)
}


// traditional method
if (a !== 1) {
  console.log(normalFunction())
} else if (b === 2) {
  console.log(arrowFunction(10, 30, 50))
} else {
  console.log('Skip');
}

// ternary opration
const valueX = (a === 1) ? normalFunction() : (b === 2) // just if and else

const loggingData = (a === 1) ? normalFunction() : (b === 2) ? arrowFunction(10, 30, 50) : 'Skip'; // if elseif and else

console.log(loggingData)


//Switch case
switch (3) {
  case 1:
    console.log(false);
    break;
  case 2:
    console.log(true);
    break;
  default:
    console.log('Nothing doing');
    break;
}



const aValue = 1
const bValue = 6
const cValue = 3

// Comparison
if (aValue === 1 && bValue === 5) {
  console.log(normalFunction())
} else if (aValue === 2 || bValue === 6) {
  console.log(arrowFunction(10, 30, 50))
} else {
  console.log('Skip');
}



// const _name = 'sakthi'

// let city = 'Chennai'
// console.log(city)
// city = "Madurai"

// console.log(city)